SMODS.Joker{ --2_10 Hour Burst Man
    key = "_210hourburstman",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = '2_10 Hour Burst Man',
        ['text'] = {
            [1] = 'Scored Kings of {C:spades}Spades{} obtain a random {C:attention}Seal{}',
            [2] = 'Scored Kings of {C:clubs}Clubs{} obtain a random {C:attention}Enhancement{}',
            [3] = '{C:inactive}Originates from{} {C:money}Item {}{C:hearts}Asylum{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["sauce_sauce_jokers"] = true },

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 13 and context.other_card:is_suit("Spades") or context.other_card:is_suit("Clubs")) then
                local enhancement_pool = {}
                for _, enhancement in pairs(G.P_CENTER_POOLS.Enhanced) do
                    if enhancement.key ~= 'm_stone' then
                        enhancement_pool[#enhancement_pool + 1] = enhancement
                    end
                end
                local random_enhancement = pseudorandom_element(enhancement_pool, 'edit_card_enhancement')
                context.other_card:set_ability(random_enhancement)
                local random_seal = SMODS.poll_seal({mod = 10, guaranteed = true})
                if random_seal then
                    context.other_card:set_seal(random_seal, true)
                end
                return {
                    message = "Card Modified!"
                }
            end
        end
    end
}