SMODS.Joker{ --Super Sonic
    key = "supersonic",
    config = {
        extra = {
            emult = 1.2
        }
    },
    loc_txt = {
        ['name'] = 'Super Sonic',
        ['text'] = {
            [1] = '{C:dark_edition}^1.2{} Mult if hand scored is all face cards',
            [2] = '{C:inactive}\"Time to scramble some Eggmen, SUPER SONIC STYLE!\"{}',
            [3] = '{C:inactive}Originates from{} {C:common}Sonic the Hedgehog{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 13
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = "sauce_unnatural",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["sauce_sauce_jokers"] = true },
    soul_pos = {
        x = 6,
        y = 13
    },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' 
          or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
    local allMatchRank = true
    for i, c in ipairs(context.scoring_hand) do
        if not (c:is_face()) then
            allMatchRank = false
            break
        end
    end
    
    return allMatchRank and #context.scoring_hand > 0
end)() then
                return {
                    e_mult = card.ability.extra.emult
                }
            end
        end
    end
}