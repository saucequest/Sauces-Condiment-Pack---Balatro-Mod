SMODS.Joker{ --Workclock Chance
    key = "workclockchance",
    config = {
        extra = {
            currentweekday = 0,
            odds = 2,
            Xmult = 2
        }
    },
    loc_txt = {
        ['name'] = 'Workclock Chance',
        ['text'] = {
            [1] = 'If day playing is on a weekend, {C:green}#2# in #3#{} chance for {X:mult,C:white}X2{} Mult',
            [2] = '{C:inactive}Chance is not changable{}',
            [3] = '{C:inactive}\"Snazzy!\"{}',
            [4] = '{C:inactive}Originates from{} {C:red}FORSAKEN{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 14
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_sauce_workclockchance') 
        return {vars = {os.date("*t", os.time()).wday, new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (7 == os.date("*t", os.time()).wday or 1 == os.date("*t", os.time()).wday) then
                if SMODS.pseudorandom_probability(card, 'group_0_0f4bc6b7', 1, card.ability.extra.odds, 'j_sauce_workclockchance', true) then
              SMODS.calculate_effect({Xmult = card.ability.extra.Xmult}, card)
          end
            end
        end
    end
}