SMODS.Joker{ --Soul
    key = "soul",
    config = {
        extra = {
            hands = 2,
            permanent = 0,
            shatter = 0,
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'Soul',
        ['text'] = {
            [1] = '{C:attention}+2{} Hands',
            [2] = 'Prevents a loss',
            [3] = '{C:red}self-destructs{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 13
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["sauce_sauce_jokers"] = true },

    calculate = function(self, card, context)
        if context.buying_card and context.card.config.center.key == self.key and context.cardarea == G.jokers  then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hands).." Hand", colour = G.C.GREEN})
                
        G.GAME.round_resets.hands = G.GAME.round_resets.hands + card.ability.extra.hands
        ease_hands_played(card.ability.extra.hands)
        
                return true
            end
                }
        end
        if context.end_of_round and context.game_over and context.main_eval  then
                return {
                    saved = true,
                    message = localize('k_saved_ex'),
                    extra = {
                        func = function()
                card:shatter()
                return true
            end,
                        colour = G.C.RED
                        }
                }
        end
    end
}