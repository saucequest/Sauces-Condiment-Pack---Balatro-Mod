SMODS.Joker{ --How Old Are You?
    key = "howoldareyou",
    config = {
        extra = {
            dollars = 1
        }
    },
    loc_txt = {
        ['name'] = 'How Old Are You?',
        ['text'] = {
            [1] = 'Gives {C:money}$1{} if Ante is 4 or less when Blind selected',
            [2] = '{C:inactive}\"I\'m 4 years old!\"{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 3,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["sauce_sauce_jokers"] = true },

    calculate = function(self, card, context)
        if context.setting_blind  then
            if G.GAME.round_resets.ante <= 4 then
                return {
                    dollars = card.ability.extra.dollars,
                    message = "Im four years old!"
                }
            end
        end
    end
}