SMODS.Joker{ --Brighteyes
    key = "brighteyes",
    config = {
        extra = {
            yes = 0,
            var1 = 0,
            respect = 0
        }
    },
    loc_txt = {
        ['name'] = 'Brighteyes',
        ['text'] = {
            [1] = 'When Blind selected, make the leftmost Joker {C:dark_edition}Polychrome{}',
            [2] = '{C:inactive}\"Is it totes adorbs?\"{}',
            [3] = '{C:inactive}Originates from{} {C:red}FORSAKEN{}',
            [4] = '{C:dark_edition}Shedletsky Joker{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["sauce_shed"] = true },

    calculate = function(self, card, context)
    if context.setting_blind then
        local editionless_jokers = SMODS.Edition:get_edition_cards(G.jokers, true)

        -- Only proceed if there's at least one editionless joker
        if #editionless_jokers > 0 then
            local eligible_card = editionless_jokers[1]  -- Always pick the leftmost editionless Joker
            local edition = poll_edition('sauce_brighteyes', nil, true, true, { 'e_polychrome' })
            eligible_card:set_edition(edition, true)
            check_for_unlock({ type = 'have_edition' })
        end
    end
end
}