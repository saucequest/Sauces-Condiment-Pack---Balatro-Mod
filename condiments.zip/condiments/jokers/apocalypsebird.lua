SMODS.Joker{ --Apocalypse Bird
    key = "apocalypsebird",
    config = {
        extra = {
            operator = 1,
            emult = 1.15,
            pb_x_mult_e1d6fb78 = 10,
            hypermult_n = 1.5,
            respect = 0,
            perma_x_mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Apocalypse Bird',
        ['text'] = {
            [1] = 'When Judgement is used, create a {C:rare}Rare{} Joker',
            [2] = 'Marks the first scoring card with a {C:attention}Red{} Seal',
            [3] = 'Played {C:attention}Red{} Seals get destroyed and then give {C:dark_edition}^1.15{} Mult',
            [4] = 'Played 2s, 3s, 4s and 5s gain a permanent {X:mult,C:white}X10{} Mult',
            [5] = 'Scored face cards get destroyed and give {X:black,C:red}(#1#)1.5{} Mult',
            [6] = 'Whenever a face card is destroyed, add an operator to {X:black,C:red}HyperMult{}',
            [7] = '{C:inactive}\"Then, in the middle of all the chaotic cries, {}someone shouted:',
            [8] = '{C:inactive}\'It\'s the beast! A big, scary monster lives in the black, dusky forest!\'\"{}',
            [9] = '{C:inactive}Originates from{} {C:red}Lobotomy {}{C:attention}Corporation{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = "sauce_unnatural",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["sauce_sauce_jokers"] = true },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' 
          or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.operator}}
    end,

    calculate = function(self, card, context)
        if context.using_consumeable  then
            if context.consumeable and context.consumeable.ability.set == 'Tarot' and context.consumeable.config.center.key == 'c_judgement' then
                return {
                    func = function()
            local created_joker = false
    if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
        created_joker = true
        G.GAME.joker_buffer = G.GAME.joker_buffer + 1
            G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker', rarity = 'Rare' })
                    if joker_card then
                        
                        
                    end
                    G.GAME.joker_buffer = 0
                    return true
                end
            }))
            end
            if created_joker then
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
            end
            return true
        end
                }
            end
        end
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if (context.other_card == context.scoring_hand[1] and not (context.other_card.seal == "Red")) then
                context.other_card:set_seal("Red", true)
                return {
                    message = "Card Modified!"
                }
            elseif context.other_card.seal == "Red" then
                context.other_card.should_destroy = true
                return {
                    e_mult = card.ability.extra.emult,
                    extra = {
                        message = "Destroyed!",
                        colour = G.C.RED
                        }
                }
            elseif (context.other_card:get_id() == 2 or context.other_card:get_id() == 3 or context.other_card:get_id() == 4 or context.other_card:get_id() == 5) then
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult or 0
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult + card.ability.extra.pb_x_mult_e1d6fb78
                return {
                    extra = { message = localize('k_upgrade_ex'), colour = G.C.MULT }, card = card
                }
            elseif context.other_card:is_face() then
                context.other_card.should_destroy = true
                card.ability.extra.operator = (card.ability.extra.operator) + 1
                return {
                    message = "Destroyed!"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    hypermult = {
    card.ability.extra.operator,
    card.ability.extra.hypermult_n
}
                }
        end
    end
}