SMODS.Joker{ --error54
    key = "error54",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'error54',
        ['text'] = {
            [1] = 'If played hand contains a 5 and a 4, give a random {C:tarot}Tarot{}',
            [2] = '{C:inactive}\"keep your arms or buy the switch 2\"{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["sauce_sauce_jokers"] = true }
}