SMODS.Joker{ --Rocket Launcher
    key = "rocketlauncher",
    config = {
        extra = {
            missilesleft = 1,
            Xmult = 2.5
        }
    },
    loc_txt = {
        ['name'] = 'Rocket Launcher',
        ['text'] = {
            [1] = '{X:mult,C:white}X2.5{} Mult on next hand',
            [2] = 'Does not give Mult at all for the run after the round',
            [3] = '{C:dark_edition}Gun Joker{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 12
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["sauce_gun"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (card.ability.extra.missilesleft or 0) == 1 then
                card.ability.extra.missilesleft = 0
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}