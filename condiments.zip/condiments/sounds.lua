SMODS.Sound{
    key="birdup",
    path="birdup.ogg",
    pitch=1,
    volume=1
}