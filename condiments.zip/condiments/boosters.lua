SMODS.Booster {
    key = 'cursed_pack',
    loc_txt = {
        name = "Cursed Pack",
        text = {
            "Pick 1 of 5 Cursed Jokers",
            "(why would you ever want this?)"
        },
        group_name = "Cursed Pack"
    },
    config = { extra = 5, choose = 1 },
    cost = 2,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        rarity = "sauce_cursed",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "sauce_cursed_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'gun_pack',
    loc_txt = {
        name = "Gun Pack",
        text = {
            "Choose 1 of 4 Gun Jokers."
        },
        group_name = "Gun Pack"
    },
    config = { extra = 4, choose = 1 },
    atlas = "CustomBoosters",
    pos = { x = 1, y = 0 },
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "sauce_gun",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "sauce_gun_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'shedletsky_pack',
    loc_txt = {
        name = "Shedletsky Pack",
        text = {
            "Choose 1 of 3 Shedletsky Jokers"
        },
        group_name = "Shedletsky Pack"
    },
    config = { extra = 3, choose = 1 },
    cost = 6,
    atlas = "CustomBoosters",
    pos = { x = 2, y = 0 },
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "sauce_shed",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "sauce_shedletsky_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}
